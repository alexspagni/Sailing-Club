/**

 * Provides Classes used both by the client and the server .<br> 
 * 
 * 
 */
package javaClass;