/**

 * Provides Response Classes used by the server to send response to a Staff member .<br> 
 * 
 * 
 */

package responseStaff;