/**

 * Provides classes defining the components for managing member Request to a Server .<br> 
 * 
 * The execution is started by main method 
 * contained in the EntryStageClient class. 
 * 
 */
 
package CircoloVelico.unipr.it;