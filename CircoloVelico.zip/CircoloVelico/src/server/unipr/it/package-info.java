/**

 * Provides classes defining the components for managing Staff member and member Request to the Server and send response to them .<br> 
 * 
 * The execution is started by main method 
 * contained in the Server.java class. 
 * 
 */
package server.unipr.it;