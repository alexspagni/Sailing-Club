/**

 * Provides classes defining the components for managing Staff member Request to a Server .<br> 
 * 
 * The execution is started by main method 
 * contained in the EntryStageClient class. 
 * 
 */
package staff.unipr.it;